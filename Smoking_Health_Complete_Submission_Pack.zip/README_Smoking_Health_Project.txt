SAPPHIRE IQ — SMOKING AND HEALTH ANALYSIS DASHBOARD
Domain: Healthcare Analytics | Primary BI tool: Microsoft Power BI

FILES
1. Smoking_Health_Analysis_Dashboard.xlsx — Executive dashboard, prepared/original data and analysis tables.
2. Smoking_Health_Analysis.csv — Power BI-ready source dataset.
3. PowerBI_DAX_Measures_and_Columns.txt — DAX calculated columns and measures.
4. PowerBI_Build_Guide.txt — Step-by-step instructions to create the PBIX report.
5. Smoking_Health_Analysis.ipynb — Python analysis notebook.
6. Smoking_Health_Analysis_Report.pdf — Project report.
7. README_Smoking_Health_Project.txt — This file.

IMPORTANT
The source CSV has 10,000 records and 15 columns with no missing values.
The Power BI PBIX is not included because it must be created and saved in Power BI Desktop.
Use the provided DAX and build guide to create it.
BP categories and smoking exposure groups are simplified, project-defined descriptive categories.
This is educational/exploratory work, not medical advice or diagnosis. Association does not prove causation.
